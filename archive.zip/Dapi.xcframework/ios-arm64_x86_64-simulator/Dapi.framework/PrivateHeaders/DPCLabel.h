//
//  DPCLabel.h
//  DapiConnect
//
//  Created by Mohammed Ennabah on 11/28/20.
//  Copyright © 2020 Dapi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DPCLabel : UILabel

@end

NS_ASSUME_NONNULL_END
