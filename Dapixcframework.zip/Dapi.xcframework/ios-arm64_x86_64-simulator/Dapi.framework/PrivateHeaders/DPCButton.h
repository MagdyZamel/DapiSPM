//
//  DPCButton.h
//  DapiConnect
//
//  Created by Mohammed Ennabah on 01/05/2020.
//  Copyright © 2020 Dapi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DPCButton : UIButton

- (instancetype)init;

@end

NS_ASSUME_NONNULL_END
